<?php
// This file is part of Moodle - https://moodle.org/
// Copyright: 2026 Moodle in Niedersachsen e. V.
// License:   https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later

defined('MOODLE_INTERNAL') || die();

$functions = [

    'block_questionfilter_get_questiontypes' => [
        'classname'      => 'block_questionfilter_external',
        'methodname'     => 'get_questiontypes',
        'description'    => 'Lädt alle in der Fragebank vorhandenen Fragetypen',
        'type'           => 'read',
        'ajax'           => true,
        'loginrequired'  => false,
        'capabilities'   => 'block/questionfilter:view',
    ],

    'block_questionfilter_search_questions' => [
        'classname'      => 'block_questionfilter_external',
        'methodname'     => 'search_questions',
        'description'    => 'Sucht Testfragen über mehrere Fragesammlungen',
        'type'           => 'read',
        'ajax'           => true,
        'loginrequired'  => false,   // Gäste erlaubt — Capability-Prüfung in der Methode
        'capabilities'   => 'block/questionfilter:view',
    ],

    'block_questionfilter_get_categories' => [
        'classname'      => 'block_questionfilter_external',
        'methodname'     => 'get_categories',
        'description'    => 'Lädt alle durchsuchbaren Fragekategorien',
        'type'           => 'read',
        'ajax'           => true,
        'loginrequired'  => false,   // Gäste erlaubt
        'capabilities'   => 'block/questionfilter:view',
    ],

    'block_questionfilter_export_questions' => [
        'classname'      => 'block_questionfilter_external',
        'methodname'     => 'export_questions',
        'description'    => 'Exportiert ausgewählte Fragen (XML, CSV, GIFT)',
        'type'           => 'read',
        'ajax'           => true,
        'loginrequired'  => true,    // Export nur für angemeldete Nutzer mit export-Capability
        'capabilities'   => 'block/questionfilter:export',
    ],
];
